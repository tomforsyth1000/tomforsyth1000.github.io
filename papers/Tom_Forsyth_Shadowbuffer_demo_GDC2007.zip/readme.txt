GDC 2007 demo of depth+ID shadowing
Tom Forsyth

This is the demo accompanying the talk - I highly recommend reading the talk first or you won't really have a good idea what's going on.


Middle mouse button: drag camera around
Mouse wheel: zoom in/out
Right mouse button: drag light around
A/D: camera left/right
W/S: camera fwd/back
Q/E: camera up/down

Show chessboard: toggles a 16x16 texel chessboard pattern in the shadowbuffer. Handy for visualising where the texels actually are

Show SB contents: fairly obvious. If depth shadows are enabled, this will show depth, otherwise it will show the shaded colour of the objects.

Show SB alpha: shows the SB's alpha channel. This is always the object's ID (even if ID buffering is disabled).

Texel spread: how far from the centre position the four ID samples are taken. The correct value is 0.5, which means the four samples are 1 texel apart. 0 simulates a single sample in the middle, which causes edge acne (see the slides)

Texel offset: D3D9 specifies you should need a 0.5 texel offset to get the sampling right, and on my Radeon 9700, that's exactly what is required. However, other cards sometimes use other offsets, and some allow the user to change it in the control panel. This is, of course, Truly Evil. If you're getting edge acne with ID buffers, you may need to adjust this until it goes away.

Shadowbuffer size: fairly obvious. Note that some cards can't do 4kx4k.

Depth debug scale: when viewing a 16-bit depth buffer as a greyscale, you basically get a single shade over the whole scene. Sliding this to the right puts a scaling on the values so you can see them. Note this has no effect on the rendering algorithm, it's just a tool to help you visualise the values in the depth buffer. You won't need to move this for an 8-bit depth buffer.

Depth offset: the bias that is applied when doing the depth comparison. Too little = surface acne. Too much = Peter Pan. You will need to adjust this differently for 8 and 16 bit depth buffers.

Negate depth offset: slightly useful for playing with backface-only rendering, where you need a negative offset to avoid Peter Pan effects. However, backface-only rendering doesn't actually work that well.

Shadow back faces: toggle to enable/disable rendering back faces into the shadowbuffer.

Shadow front faces: toggle to enable/disable rendering front faces into the shadowbuffer.

Depth shadow: enables depth shadowing

ID shadow: enables ID shadowing

Neither enabled = no shadows
Just ID enabled = 8-bit ID shadows
Just depth enabled = 16-bit depth shadows
Both ID + depth enabled = 8-bit depth + 8-bit ID shadows




Ignore the fairly random shadows around the edge of the large ground plane - they're caused by the fact that I'm not selecting the shadowbuffer field of view in any sensible way, so they're off the edge of the shadowbuffer texture. You get different sorts of wrongness depending of whether you're using depth or ID. The important shadows are those of the objects, as the frustum is mainly focussed on them.

The one interesting part of the ground plane is that it is actually a bunch of plates stuck together. This is to explore the problem of shadows between abutting objects. If you turn on just ID buffers and set the texel spread to 0 (simulating only one texture sample), you can see the big problem of edge acne between abutting objects. Setting the spread to 0.5 texels (four samples one texel apart) fixes the problem.



Note that even the best methods show a little bit of acne on triangles that are almost edge-on to the light. This is because geometrically, these triangles are actually facing away from the light - strictly speaking they SHOULD be in shadow. However, because the normals are averages of the neighbouring faces, these can still face slightly towards the light and be slightly lit. This is very obvious on the toruses, because they're not very highly tesselated. There are a variety of possible solutions to this, but I didn't implement them here.




A rant about hardware:

On my elderly Radeon 9700 Pro, this demo works fine. When tried on someone's laptop with a GeForce 7900 Go in it, two things failed to work properly.

-The texel offset was set incorrectly. Instead of being 0.5, it was something close-but-not-quite-right - maybe about 0.3? They also allow you to set the offset in the control panel, which is Sick Wrong and Evil. So I had to add in the "Texel offset" slider to allow people to compensate. Presumably in a real shipping game, you'd have to render with a bunch of offsets, read the framebuffer back, and detect what offset you needed. Argh.

-There was some crazy quantisation going on. I don't understand why - I only require 16-bit precision at most, which is easily within range of both cards, especially as the 7900 is two generations more recent than the 9700! This meant that surface acne was even more crazy than I expected. I wonder if the 7900 was sneakily dropping back to float16 internal precision. Did I mention Sick Wrong and Evil?



TomF
10th March 2007
www.eelpi.gotdns.org

